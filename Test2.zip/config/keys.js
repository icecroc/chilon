module.exports = {
  mongoURI: 'mongodb://test:test!2321@ds219879.mlab.com:19879/chilon',
  jwt: 'dev-jwt'
}